const sql = require('mssql');

module.exports = async function (context, req) {
    const title = req.query.title;
    if (!title) {
        context.res = {
            status: 400,
            body: "Title parameter is required."
        };
        return;
    }

    context.res = {
        headers: {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type, Authorization',
            'Cache-Control': 'no-store'
        }
    };

    if (req.method === 'OPTIONS') {
        context.res.status = 200;
        return;
    }

    try {
        await sql.connect('Server=tcp:serverless-imdb-db-server.database.windows.net;Port=1433;Initial Catalog=serverless-imdb-db;User ID=MoniMonkata126126;Password=MoniMonkata126;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;');
        const result = await sql.query`SELECT ImageUrl FROM Films WHERE Title = ${title}`;
        sql.close();

        if (!result.recordset || result.recordset.length === 0 || !result.recordset[0].ImageUrl) {
            context.res = {
                status: 404,
                body: "Thumbnail image URL not found for the given title."
            };
            return;
        }

        const imageUrl = result.recordset[0].ImageUrl;

        context.res = {
            status: 200,
            body: { imageUrl }
        };
    } catch (err) {
        console.error('Error: ', err);
        context.res = {
            status: 500,
            body: err.message
        };
    }
};
