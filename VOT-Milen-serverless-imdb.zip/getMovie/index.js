const sql = require('mssql');

module.exports = async function (context, req) {
    const title = req.query.title;
    if (!title) {
        context.res = {
            status: 400,
            body: "Title parameter is required."
        };
        return;
    }

    context.res = {
        headers: {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type, Authorization',
            'Cache-Control': 'no-store'
        }
    };

    if (req.method === 'OPTIONS') {
        context.res.status = 200;
        return;
    }

    try {
        await sql.connect('Server=tcp:serverless-imdb-db-server.database.windows.net;Port=1433;Initial Catalog=serverless-imdb-db;User ID=MoniMonkata126126;Password=MoniMonkata126;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;');

        // Query to retrieve all columns (except ID columns) for the movie from the Films table
        const filmResult = await sql.query`SELECT Title, Year, Genre, Description, Director, Actors, ImageUrl FROM Films WHERE Title = ${title}`;

        // Query to retrieve all opinions for the movie from the FilmOpinions table
        const opinionResult = await sql.query`SELECT Opinion, Rating, DateTime, Author FROM FilmOpinions WHERE FilmId IN (SELECT Id FROM Films WHERE Title = ${title})`;

        sql.close();

        if (!filmResult.recordset || filmResult.recordset.length === 0) {
            context.res = {
                status: 404,
                body: "Movie not found in the database."
            };
            return;
        }

        const movieDetails = filmResult.recordset[0];
        const opinions = opinionResult.recordset;

        context.res = {
            status: 200,
            body: {
                movieDetails,
                opinions
            }
        };
    } catch (err) {
        console.error('Error: ', err);
        context.res = {
            status: 500,
            body: err.message
        };
    }
};
