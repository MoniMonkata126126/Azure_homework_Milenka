const Joi = require('joi');
const sql = require('mssql');

module.exports = async function (context, req) {
    const schema = Joi.object({
        title: Joi.string().required(),
        opinion: Joi.string().required(),
        rating: Joi.number().integer().min(1).max(10).required(),
        dateTime: Joi.date().required(),
        author: Joi.string().required()
    });

    const validationResult = schema.validate(req.body);
    if (validationResult.error) {
        context.res = {
            status: 400,
            body: validationResult.error.details[0].message
        };
        return;
    }

    const opinionInfo = req.body;
    try {
        await sql.connect('Server=tcp:serverless-imdb-db-server.database.windows.net;Port=1433;Initial Catalog=serverless-imdb-db;User ID=MoniMonkata126126;Password=MoniMonkata126;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;');

        await sql.query`IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'Films') CREATE TABLE Films (Id INT PRIMARY KEY IDENTITY, Title NVARCHAR(100), Year INT, Genre NVARCHAR(100), Description NVARCHAR(MAX), Director NVARCHAR(100), Actors NVARCHAR(MAX), ImageUrl NVARCHAR(MAX), AverageRating FLOAT)`;

        await sql.query`IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'FilmOpinions') CREATE TABLE FilmOpinions (Id INT PRIMARY KEY IDENTITY, FilmId INT FOREIGN KEY REFERENCES Films(Id), Opinion NVARCHAR(MAX), Rating INT, DateTime DATETIME, Author NVARCHAR(100))`;

        const filmIdResult = await sql.query`SELECT Id FROM Films WHERE Title = ${opinionInfo.title}`;
        if (filmIdResult.recordset.length === 0) {
            context.res = {
                status: 404,
                body: "Film with the provided title does not exist."
            };
            return;
        }
        const filmId = filmIdResult.recordset[0].Id;

        await sql.query`INSERT INTO FilmOpinions (FilmId, Opinion, Rating, DateTime, Author) VALUES (${filmId}, ${opinionInfo.opinion}, ${opinionInfo.rating}, ${opinionInfo.dateTime}, ${opinionInfo.author})`;

        context.res = {
            status: 200,
            body: "Film opinion saved successfully."
        };
    } catch (err) {
        console.error('Error: ', err);
        context.res = {
            status: 500,
            body: err.message
        };
    }
};
